# Rádio Moto — protótipo 0.1

Protótipo Android nativo para testar descoberta/conexão Wi‑Fi Direct e fluxo de áudio PCM entre dois aparelhos. Não usa internet nem dados móveis. Bluetooth pode ser usado pelo Android como rota de áudio do fone/intercomunicador.

## Abrir e instalar
1. Instale Android Studio em um computador.
2. Extraia o ZIP e abra a pasta `RadioMoto` no Android Studio.
3. Aguarde a sincronização do Gradle e instale em dois Androids físicos (emuladores não são adequados para Wi‑Fi Direct).
4. Ative Wi‑Fi nos dois celulares. Conceda permissões de dispositivos próximos/localização (conforme Android) e microfone.
5. Em ambos, mantenha o app aberto. Em um celular, procure dispositivos; no outro, também deixe a busca ativa. Selecione o aparelho encontrado e toque em conectar. O Android pode exibir uma confirmação do sistema.
6. Quando conectar, teste com fones. O celular que hospeda aguarda a conexão TCP; o outro inicia a conexão de áudio automaticamente.

## Limitações conhecidas
- É um protótipo experimental, não um aplicativo pronto para uso em trânsito.
- Wi‑Fi Direct e descoberta variam por fabricante/versão Android; pode ser necessário iniciar a criação do grupo pelo diálogo do sistema ou ajustar permissões em aparelhos específicos.
- Esta versão é somente ponto a ponto (dois celulares). Não implementa mesh, repetição de sinal, grupos, criptografia, reconexão automática ou PTT.
- O áudio é PCM sem compressão, com latência e consumo de bateria potencialmente altos. O envio bidirecional simultâneo depende do modo de áudio e da rede do aparelho; teste primeiro com volume baixo e fones para evitar microfonia.
- A seleção de saída Bluetooth é controlada pelo Android. Conecte o fone/intercomunicador antes de abrir o app.
- Não use durante a pilotagem. Teste parado, em ambiente seguro.

## Se a conexão falhar
Wi‑Fi Direct não é igualmente suportado em todos os modelos. Anote marca/modelo, versão Android e mensagem exibida nos dois celulares. Este código é uma base inicial e pode precisar de correções específicas para os aparelhos.
