package com.radiomoto

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.net.wifi.p2p.*
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import android.media.*
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var receiver: BroadcastReceiver
    private val peers = mutableListOf<WifiP2pDevice>()
    private lateinit var peerAdapter: ArrayAdapter<String>
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var connectButton: Button
    private lateinit var talkButton: Button
    private var connected = false
    private var groupOwner = false
    private var socket: Socket? = null
    private var server: ServerSocket? = null
    private val executor = Executors.newCachedThreadPool()
    private val running = AtomicBoolean(false)
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private val port = 8988
    private val sampleRate = 16000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper, null)
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                        if (hasPermissions()) manager.requestPeers(channel) { info ->
                            peers.clear(); peers.addAll(info.deviceList)
                            peerAdapter.clear()
                            peers.forEach { peerAdapter.add("${it.deviceName}  (${it.statusText()})") }
                            peerAdapter.notifyDataSetChanged()
                        }
                    }
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                        manager.requestConnectionInfo(channel) { info ->
                            connected = info.groupFormed
                            groupOwner = info.isGroupOwner
                            if (connected) {
                                status.text = if (groupOwner) "Conectado: este celular é o anfitrião." else "Conectado: aguardando áudio."
                                if (groupOwner) startServer()
                                else executor.execute {
                                    try {
                                        Thread.sleep(1200)
                                        val s = Socket(info.groupOwnerAddress.hostAddress, port)
                                        socket = s
                                        runOnUiThread { status.text = "Conectado aos dois celulares. Pode testar o áudio." }
                                        startAudio(s)
                                    } catch (e: Exception) { showError("Falha ao abrir áudio: ${e.message}") }
                                }
                            } else status.text = "Ainda não conectado. Procure celulares próximos."
                        }
                    }
                }
            }
        }
        requestNeededPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 24); setBackgroundColor(0xFF111111.toInt()) }
        fun label(t: String, size: Float = 16f) = TextView(this).apply { text=t; textSize=size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,10,0,10) }
        root.addView(label("RÁDIO MOTO", 26f))
        root.addView(label("Protótipo local • 2 celulares • sem internet"))
        status = label("Ative o Wi-Fi nos dois aparelhos e conceda as permissões.")
        root.addView(status)
        val scan = Button(this).apply { text="Procurar celulares"; setOnClickListener { discover() } }
        root.addView(scan)
        list = ListView(this).apply { dividerHeight=1 }
        peerAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        list.adapter = peerAdapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        connectButton = Button(this).apply {
            text="Conectar ao celular selecionado"
            setOnClickListener {
                val pos = list.checkedItemPosition
                if (pos == ListView.INVALID_POSITION || pos !in peers.indices) { status.text="Selecione um celular na lista."; return@setOnClickListener }
                val config = WifiP2pConfig().apply { deviceAddress = peers[pos].deviceAddress }
                status.text="Solicitando conexão..."
                manager.connect(channel, config, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { status.text="Pedido enviado. Aguarde o outro celular aceitar, se solicitado." }
                    override fun onFailure(reason: Int) { status.text="Não foi possível conectar. Código: $reason" }
                })
            }
        }
        root.addView(connectButton)
        talkButton = Button(this).apply { text="INICIAR ÁUDIO"; isEnabled=false; setOnClickListener { if (!running.get()) startAudio(socket) } }
        root.addView(talkButton)
        root.addView(label("Para testar: um celular cria o grupo; o outro procura e conecta. O anfitrião inicia o servidor automaticamente."))
        setContentView(root)
        list.choiceMode = ListView.CHOICE_MODE_SINGLE
    }

    private fun WifiP2pDevice.statusText() = when(status) {
        WifiP2pDevice.AVAILABLE -> "disponível"
        WifiP2pDevice.CONNECTED -> "conectado"
        WifiP2pDevice.INVITED -> "convidado"
        else -> "status $status"
    }

    private fun hasPermissions(): Boolean = if (Build.VERSION.SDK_INT >= 33)
        checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
         checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestNeededPermissions() {
        val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES, Manifest.permission.RECORD_AUDIO)
                else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.RECORD_AUDIO)
        val missing = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 10)
    }

    private fun discover() {
        if (!hasPermissions()) { requestNeededPermissions(); return }
        status.text="Procurando dispositivos Wi-Fi Direct..."
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { status.text="Busca iniciada. Aguarde alguns segundos." }
            override fun onFailure(reason: Int) { status.text="Busca falhou. Verifique Wi-Fi/permissões. Código: $reason" }
        })
    }

    private fun startServer() {
        executor.execute {
            try {
                server = ServerSocket(port)
                val s = server!!.accept()
                socket = s
                runOnUiThread { status.text="Celular conectado. Áudio pronto." }
                startAudio(s)
            } catch (e: Exception) { showError("Servidor de áudio: ${e.message}") }
        }
    }

    private fun startAudio(s: Socket?) {
        if (s == null || !running.compareAndSet(false, true)) return
        try {
            val minIn = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val minOut = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            audioRecord = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn, 2048))
            audioTrack = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(minOut, 2048)).setTransferMode(AudioTrack.MODE_STREAM).build()
            audioRecord?.startRecording(); audioTrack?.play()
            runOnUiThread { talkButton.isEnabled=true; talkButton.text="ÁUDIO ATIVO (parar ao fechar)" ; status.text="Áudio ativo. Use fone; evite volume alto para não gerar microfonia." }
            val input = s.getInputStream(); val output = s.getOutputStream()
            executor.execute {
                val buf=ByteArray(640)
                try { while(running.get()) { val n=audioRecord?.read(buf,0,buf.size) ?: -1; if(n>0) { output.write(buf,0,n); output.flush() } } }
                catch (_: Exception) { stopAudio() }
            }
            executor.execute {
                val buf=ByteArray(640)
                try { while(running.get()) { val n=input.read(buf); if(n<0) break; audioTrack?.write(buf,0,n) } }
                catch (_: Exception) { stopAudio() }
            }
        } catch (e: Exception) { stopAudio(); showError("Áudio não iniciou: ${e.message}") }
    }

    private fun stopAudio() {
        running.set(false)
        try { audioRecord?.stop(); audioRecord?.release() } catch (_: Exception) {}
        try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
        audioRecord=null; audioTrack=null
    }

    private fun showError(message: String) { runOnUiThread { status.text=message } }

    override fun onResume() {
        super.onResume()
        val filter=IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        registerReceiver(receiver, filter)
    }
    override fun onPause() { super.onPause(); try { unregisterReceiver(receiver) } catch (_: Exception) {} }
    override fun onDestroy() {
        stopAudio()
        try { socket?.close(); server?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
